#include "perf_precomp.hpp"

using namespace std;
using namespace cv;
using namespace perf;
using std::tr1::make_tuple;
using std::tr1::get;

CV_ENUM(InpaintingMethod, INPAINT_NS, INPAINT_TELEA)
typedef std::tr1::tuple<Size, InpaintingMethod> InpaintArea_InpaintingMethod_t;
typedef perf::TestBaseWithParam<InpaintArea_InpaintingMethod_t> InpaintArea_InpaintingMethod;


PERF_TEST_P(InpaintArea_InpaintingMethod, inpaint,
            testing::Combine(
                SZ_ALL_SMALL,
                testing::ValuesIn(InpaintingMethod::all())
                )
            )
{
    Mat src = imread(getDataPath("gpu/hog/road.png"));

    Size sz = get<0>(GetParam());
    int inpaintingMethod = get<1>(GetParam());

    Mat mask(src.size(), CV_8UC1, Scalar(0));
    Mat result(src.size(), src.type());

    Rect inpaintArea(src.cols/3, src.rows/3, sz.width, sz.height);
    mask(inpaintArea).setTo(255);

    declare.in(src, mask).out(result).time(30);

    TEST_CYCLE() inpaint(src, mask, result, 10.0, inpaintingMethod);

    Mat inpaintedArea = result(inpaintArea);
    SANITY_CHECK(inpaintedArea);
}
